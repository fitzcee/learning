package com.infiniteskills.utilities;

public enum EncryptOptions {
	ENCRYPT, 
	DECRYPT;
}
